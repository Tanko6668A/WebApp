import sqlite3

conn = sqlite3.connect('login.db')

cursor = conn.cursor()

cursor.execute("""
CREATE TABLE Student(
    user_id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL,
    password TEXT NOT NULL
);
""")

conn.commit()  # make changes to db
conn.close()  # closes the connection
